#!/usr/bin/env python
#
#author: Brandon Paikoff
#group: tplab, Vanderbilt University
#date: 06-04-15
#
# passing in any argument will cause this script to only run first data point in sweep
# this is useful for setting muffin tin radii in elk

import numpy as np
import subprocess
import shutil
import sys
import os
import glob
from scipy.optimize import leastsq
sys.dont_write_bytecode = True

# passing in any argument will cause this script to only run first data point in sweep
if len(sys.argv) > 1:
    only_run_first_point = True
else:
    only_run_first_point = False

from eosfit_in import cell_shape, energy_driver_name, s_guess, s_pert, n_points
if cell_shape in ['hex', 'hexagonal', 'Hexagonal']:
    print 'make sure scale_a and scale_c in eosfit.in match elk.in.template file!!!'
    from eosfit_in import scale_a, scale_c
    

def main():
    # remove old work directories
    workdir_filenames = glob.glob('workdir_s.*')
    for f in workdir_filenames:
        shutil.rmtree(f)

    # Create independent variable (scale) values over which to evaluate energy.
    # The paramters for this are defined in eosfit input file.
    s_array = s_guess * np.linspace(1.-s_pert, 1.+s_pert, n_points)
    # convert scale values to lattice constant and volumes for later
    a_array = a_of_s(s_array, cell_shape)
    vol_array = vol_of_s(s_array, cell_shape) 
    
    # calculate energy at each scale
    # energy driver is defined in eosfit input file
    E_array = np.zeros(s_array.shape) 
    for i, s in enumerate(s_array):
        E_array[i] = calculate_energy(i, s, energy_driver_name)

    # Write energy vs scale/vol/lattice constant data to file.
    write_arrays(s_array, a_array, vol_array, E_array, n_points)  

    # fit E vs. vol data to murnaghan equation of state
    fitted_murnaghan_parameters, ier = fit_to_murnaghan(vol_array, E_array)
    E_0 = fitted_murnaghan_parameters[0]
    B_0 = fitted_murnaghan_parameters[1]
    B_0p = fitted_murnaghan_parameters[2] 
    V_0 = fitted_murnaghan_parameters[3]
    # 
    s_0 = s_of_vol(V_0, cell_shape) #convert V_0 to scale
    a_0 = a_of_s(s_0, cell_shape) # convert s_0 to lattice constant
   
    # calculate RMS error of fit
    rms_error = calc_rms_error(fitted_murnaghan_parameters, vol_array, E_array)
 
    # write fit results to file
    write_fit(E_0, B_0, B_0p, V_0, s_0, a_0, rms_error)


# writes energy vs scale/vol/lattice_constant data to file
def write_arrays(s_array, a_array, vol_array, E_array, n_points):
    with open('energies.dat', 'w') as f:
        f.write('# Lattice vector scale, Lattice Constant, '
                'Unit cell volume, Energy\n')
        for n in range(0, n_points):
            f.write('%.9f    %.9f    %.9f    %.9f\n' 
                    %(s_array[n], a_array[n], vol_array[n], E_array[n]))


def write_fit(E_0, B_0, B_0p, V_0, s_0, a_0, rms_error):
    
    # convert results to other units
    a_angstroms = a_0 * 0.52917725
    B_0_gpa = B_0 * 1.8218779e-30 / 5.2917725e-11 / \
              4.8377687e-17 / 4.8377687e-17 * 1.e-9
    
    with open('murnaghan_parameters.dat', 'w') as f:
        f.write('# everything in rydberg atomic units unless specified\n')
        f.write('E_0: %.9f\n'  %E_0)
        f.write('B_0 (bulk modulus): %.9g\n' %B_0)
        f.write('B_0p: %.9f\n' %B_0p)
        f.write('V_0: %.9f\n' %V_0)
        f.write('\n')
        f.write('s_0, lattice vector scale: %.9f\n' %s_0)
        f.write('a_0, lattice constant: %.9f\n' %a_0)
        f.write('\n')
        f.write('B_0 (GPa): %.9f\n' %B_0_gpa)
        f.write('a_0 (angstroms): %.9f\n' %a_angstroms)
        f.write('\n')
        f.write('RMS error: %.9g\n' %rms_error)
    

# NOTES ABOUT CELL SHAPES:
# fcc shape assumes lattice vectors are integer multiples of
# a1=(1,1,0), a2=(0,1,1), and a3=(1,0,1)
# cubic assumes lattice vectors are integer multiples of
# a1=(1,0,1), a2=(0,1,0), and a3=(0,0,1)

# unit cell volume as a function of lattice vector scale
def vol_of_s(s, cell_shape):
    if cell_shape in ['hex', 'hexagonal', 'Hexagonal']:
        # for hexagonal cells, s is scaling scale_a and scale_c
        unscaled_vol = (scale_a**2)*np.sin(2./3.*np.pi) * scale_c  
        return s**3 * unscaled_vol
    if cell_shape in ['fcc', 'FCC', 'Fcc']:
        return 2. * (s**3.)
    if cell_shape in ['cubic', 'CUBIC', 'Cubic']:
        return s**3.
    if cell_shape in ['bcc', 'BCC', 'Bcc']:
        print "bcc not implemented yet"
        exit()


# lattice constant as a function of lattice vector scale
def a_of_s(s, cell_shape):    
    if cell_shape in ['hex', 'hexagonal', 'Hexagonal']:
        # for hexagonal cells, a is actually two numbers.
        # a is only used for file output
        # to avoid messing up code, I'll out put a=s
        return s
    if cell_shape in ['fcc', 'FCC', 'Fcc']:
        return 2.*s
    if cell_shape in ['cubic', 'CUBIC', 'Cubic']:
        return s
    if cell_shape in ['bcc', 'BCC', 'Bcc']:
        print "bcc not implemented yet"
        exit()


# lattice constant as a function of lattice vector scale
def s_of_vol(vol, cell_shape):    
    if cell_shape in ['hex', 'hexagonal', 'Hexagonal']:
        # for hexagonal cells, s is scaling scale_a and scale_c
        unscaled_vol = (scale_a**2)*np.sin(2./3.*np.pi) * scale_c  
        return (vol/unscaled_vol)**(1./3.)
    if cell_shape in ['fcc', 'FCC', 'Fcc']:
        return (vol/2.)**(1./3.)
    if cell_shape in ['cubic', 'CUBIC', 'Cubic']:
        return vol**(1./3.)  
    if cell_shape in ['bcc', 'BCC', 'Bcc']:
        print "bcc not implemented yet"
        exit()


def calculate_energy(i, s, energy_driver_name):
    # copy template directory to work directory.
    # template directory is set up by user
    workdir_name = 'workdir_s.'+'%s' %str(i+1)
    shutil.copytree('templatedir', workdir_name, symlinks=True)
    os.chdir(workdir_name)
    print 'Running ', energy_driver_name, ' in ', workdir_name

    if energy_driver_name == 'parabola':
        # parabola with added noise, used for testing other parts of scripts
        # sometimes fit doesn't converge though

        # polynomial coefficients
        a = 0.53470909
        b = -6.43713213
        c = 19.32484136
        # random perturbation from parabola
        noise = np.random.uniform(0.995,1.005)
        # return parabola with noise
        energy = a*s**2. + b*s + c + noise

    if energy_driver_name == 'socorro':
        # edit scale in crystal file
        socorro_edit_scale(s)

        # call socorro
        with open('socorro.out', 'w') as soc_fout:
            subprocess.call(['socorro'], stdout=soc_fout)

        # read energy from socorro output
        energy = soc_get_energy()

    if energy_driver_name == 'elk':
        # edit scale in elk.in
        elk_edit_scale(s)

        # call elk
        with open('elk.out', 'w') as elk_fout:
            subprocess.call(['elk'], stdout=elk_fout)

        # read energy from INFO.OUT or TOTENERGY.DAT
        energy = elk_get_energy()

    # exit work directory
    os.chdir('..')
    if only_run_first_point == True:
        # exit after first point: useful when testing elk muffin tin radius adjustment
        exit()
    return energy


def socorro_edit_scale(s):
    with open('data/crystal.template') as fin, open('data/crystal', 'w') as fout:
        for line in fin:
            line = line.replace('{scale}', str(s))
            fout.write(line)
    os.remove('data/crystal.template')


# reads and returns energy from socorro output file, diaryf
def soc_get_energy():
    with open('diaryf', 'r') as diaryf_fin:
        diary = diaryf_fin.readlines()

    # finds line with final cell energy
    for line in diary:
        if 'cell energy   ' in line:
            soc_energy = line.split()[3]
    return soc_energy


def elk_edit_scale(s):
    with open('elk.in.template') as fin, open('elk.in', 'w') as fout:
        for line in fin:
            line = line.replace('{scale}', str(s))
            fout.write(line)
    os.remove('elk.in.template')


def elk_get_energy():
    elk_energy_all_iterations = np.loadtxt('TOTENERGY.OUT')
    elk_energy = elk_energy_all_iterations[-1]
    elk_energy_rydbergs = 2.*elk_energy
    return elk_energy_rydbergs


def fit_to_murnaghan(vol_array, E_array):
        ### first, fit a parabola to the data
        # y = ax^2 + bx + c
        a, b, c = np.polyfit(vol_array, E_array, 2)
        #
        # the parabola does not fit the data very well, but we can use it to get
        # some analytical guesses for other parameters.
        # V0 = minimum energy volume, or where dE/dV=0
        # E = aV^2 + bV + c
        # dE/dV = 2aV + b = 0
        # V0 = -b/2a
        # E0 is the minimum energy, which is:
        # E0 = aV0^2 + bV0 + c
        # B is equal to V0*d^2E/dV^2, which is just 2a*V0
        # and from experience we know Bprime_0 is usually a small number like 4
        V0_guess = -b/(2*a)
        E0_guess = a*V0_guess**2. + b*V0_guess + c
        B0_guess = 2.*a*V0_guess
        BP_guess = 4.

        murnpars_guess = [E0_guess, B0_guess, BP_guess, V0_guess]
        murnpars = leastsq(objective, murnpars_guess, args=(E_array,vol_array))
        return murnpars

def calc_rms_error(murnpars, vol_array, E_calculated):
    # E_calculated contains energies for volumes in vol_array
    #   as calculated by the electronic structure code
    E_murnaghan = murnaghan(murnpars, vol_array)
    #
    # error between murnaghan fit and data
    E_error = E_murnaghan - E_calculated
 
    return np.sqrt(np.mean(np.square(E_error)))

# murnaghan equation of state
def murnaghan(parameters, vol):
    # given a vector of parameters and volumes, return a vector of energies.
    # equation From PRB 28,5480 (1983)
    E0 = parameters[0]
    B0 = parameters[1]
    BP = parameters[2]
    V0 = parameters[3]
    E = E0 + B0*vol/BP*(((V0/vol)**BP)/(BP-1)+1) - V0*B0/(BP-1.)
    return E


def objective(pars,y,x):
        err = y -  murnaghan(pars,x)
        return err


if __name__ == '__main__':
    main()
