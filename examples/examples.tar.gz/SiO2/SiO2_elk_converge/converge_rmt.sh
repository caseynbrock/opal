#!/bin/bash

# input files have already been set up
# echo "--- RGKMAX=7 ---"
# cd rgkmax7
# ./murnaghan_main.py
# cd ..

echo "--- RGKMAX=7.5 ---"
cd rgkmax7.5
./murnaghan_main.py
cd ..

echo "--- RGKMAX=8.0 ---"
cd rgkmax8
./murnaghan_main.py
cd ..

echo "--- RGKMAX=8.5 ---"
cd rgkmax8.5
./murnaghan_main.py
cd ..

echo "--- RGKMAX=9.0 ---"
cd rgkmax9
./murnaghan_main.py
cd ..

echo "--- RGKMAX=9.5 ---"
cd rgkmax9.5
./murnaghan_main.py
cd ..

