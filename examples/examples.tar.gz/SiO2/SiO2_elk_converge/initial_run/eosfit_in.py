# this is going to be an input file for our eos fit scripts
# doesn't work yet

cell_shape = 'hex'
scale_a = 10. 
scale_c = 10.

energy_driver_name = 'elk'

# this is scaling vectors that are already scaled
# see elk.in.template
s_guess = 1.00

s_pert = 0.05

n_points = 9
