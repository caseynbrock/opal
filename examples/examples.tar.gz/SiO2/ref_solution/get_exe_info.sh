#!/bin/bash
# writes executable and linked librry info for programs used in moga
# 08/11/14


# write dakota executable and linked library info
printf "DAKOTA EXECUTABLE:\n"     
ls -l $(which dakota)             
printf "\nVERSION INFO:\n"        
dakota -version                   
printf "\nLINKED LIBRARY INFO:\n" 
ldd -v $(which dakota)            

# write elk executable and linked library info
printf "ELK EXECUTABLE:\n"     
ls -l $(which elk)             
printf "\nLINKED LIBRARY INFO:\n" 
ldd -v $(which elk) 

## write atompaw executable and linked library info
#printf "\n\n\nATOMPAW EXECUTABLE:\n" 
#ls -l $(which atompaw)               
#printf "\nLINKED LIBRARY INFO:\n"    
#ldd -v $(which atompaw)              

## write socorro executable info and linked library info
#printf "\n\n\nSOCORRO EXECUTABLE:\n"  
#ls -l $(which socorro)                
#printf "\nLINKED LIBRARY INFO:\n"     
#ldd -v $(which socorro)               
