#/bin/bash
# This wrapper reads perturbation input from Dakota, 
# writes elk.in based on elk.in.template,
# runs elk,
# read forces from elk,
# writes forces output to Dakota results file 
#
# author Casey Brock

# read Dakota params file and write elk.in using elk.in.template
# uses dprepro utility
dprepro $1 elk.in.template elk.in

# run elk
export OMP_NUM_THREADS=1
elk &> elk.out

#remove unnecessary elk output files (to save A LOT of disk space)
rm -f DTOTENERGY.OUT EQATOMS.OUT FERMIDOS.OUT LATTICE.OUT SYMLAT.OUT EFERMI.OUT EVALCORE.OUT GAP.OUT LINENGY.OUT SYMSITE.OUT EIGVAL.OUT EVALFV.OUT GEOMETRY.OUT OCCSV.OUT TOTENERGY.OUT EVALSV.OUT IADIST.OUT RMSDVS.OUT EVECFV.OUT STATE.OUT EVECSV.OUT KPOINTS.OUT SYMCRYS.OUT MOMENT*.OUT

# read forces from INFO.OUT file
python ../elk_get_forces.py forces.dat

# read forces from forces.dat and write to results file
tail -n+2 forces.dat | awk '{print $1; print $2; print $3}' > results.tmp

# # move tmp file to dakota results file
mv results.tmp $2
