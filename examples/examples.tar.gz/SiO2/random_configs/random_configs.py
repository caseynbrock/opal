"""
Created on Wed Jul 16 13:21:16 2014

@author: Izany
"""
"""
Edited 08/06/14
by Casey Brock

Original is is Izany's files: /home/mdsallmi/python_configurations/lattice_argv_no_plot.py


This script randomly perturbs atoms in a unit cell and calculates the distances between all atoms in the unit cell and surrounding unit cells. If no atoms are closer than reject_distance, then a configuration is accepted. Accepted configurations are written to a file. Once num_configs configurations have been accepted, the process stops.

IT IS OKAY IF AN ATOM IS PLACED OUTSIDE THE UNIT CELL BECAUSE BOTH ELK AND SOCORRO WILL MOVE IT INSIDE THE UNIT CELL.

filename:         name of the output file 
no_configs:       number of random configurations to generate
no_atoms:         total number of atoms in the unit cell
no_fixed:         number of atoms in the unit cell with FIXED postions. The positions must be specified in lattice coordinates
constant:         scale factor for the lattice vectors
reject_distance:  minimum distance between atoms in a random configuration
fixed_atoms:      positions of fixed atoms in lattice coordinates
free_atoms_equil: equilibrium positions of free atoms. free atoms are perturbed from these locations
pert_min:         minimum perturbation amount (lattice coordinates)
pert_max:         maximum perturbation amount (lattice coordinates)
vectora, vectorb, and vectorc: lattice vectors


NOTE: This was made to create random perturbations from equilibrium. If you want to drop the atoms in the unit cell randomly make the equilibrium positions (0, 0, 0) and the perturbation range 0 to 1.
"""

import sys
import random
import math
import numpy as np
import os

### USER INPUTS ###############################################################
filename = "configs.dat"  #output file
no_configs = 4
no_atoms  = 9  # total number of atoms in unit cell
no_fixed  = 0  # number of fixed position atoms in unit cell
no_free   = no_atoms-no_fixed   # number of free atoms (poitions generated randomly)

#scale for lattice vectors
constant =  1.  #arbitrary if reject distance is a fraction of constant

#lattice vectors
scale_a = 9.2850 # bohr
scale_c = 10.2143 # bohr
vectora = constant * scale_a * np.array([1.,    0.,                  0. ])
vectorb = constant * scale_a * np.array([-0.5,  0.8660254037844386,  0. ])
vectorc = constant * scale_c * np.array([0.,    0.,                  1. ])

# coordinates of fixed atoms (lattice coordinates)
fixed_atoms      = np.zeros([no_fixed,3])
# fixed_atoms[0,:] = [0.0, 0.0, 0.0]

# equilibrium positions of free atoms
free_atoms_equil = np.zeros([no_free,3])
free_atoms_equil[0,:]  = [0.4697, 0     , 0     ]
free_atoms_equil[1,:]  = [0     , 0.4697, 0.6667]
free_atoms_equil[2,:]  = [0.5303, 0.5303, 0.3333]
free_atoms_equil[3,:]  = [0.4133, 0.2672, 0.1188]
free_atoms_equil[4,:]  = [0.2672, 0.4133, 0.5479]
free_atoms_equil[5,:]  = [0.7328, 0.1461, 0.7855]
free_atoms_equil[6,:]  = [0.5867, 0.8539, 0.2145]
free_atoms_equil[7,:]  = [0.8539, 0.5867, 0.4521]
free_atoms_equil[8,:]  = [0.1461, 0.7328, 0.8812]

# perturbation range (LATTICE COORDINATES !!!)
# these can be reduced to speed up generation of random configs
pert_min = -0.1  # minimum perturbation (in lattice coordinates) from equilibrium positions
pert_max =  0.1  # maximum perturbation (in lattice coordinates) from equilibrium positions

# minimum distance between atoms
reject_distance = 0.8 * constant * 3.0728 #80% of equilibrium distance for diamond cubic or zinc blende structures (so ~20% perturbations)
# equilirbium distance is constant*3.0728bohr in equilibrium. 
###############################################################################


#random.seed(1)

no_dim  = 3                 # 3D

# open output file
fout = open (filename, 'w')

# print input paramters as header
fout.write('# Number of configurations: ' + str(no_configs))
fout.write('\n# Minimum distance between atoms: ' + str(reject_distance))
fout.write('\n# Perturbation range (lattice coordinates): ' + str(pert_min) + ' to ' + str(pert_max))
fout.write('\n# Lattice vectors (unscaled):')
fout.write('\n# ' + str(vectora[0]) + ' ' + str(vectora[1]) + ' ' + str(vectora[2]) )
fout.write('\n# ' + str(vectorb[0]) + ' ' + str(vectorb[1]) + ' ' + str(vectorb[2]) )
fout.write('\n# ' + str(vectorc[0]) + ' ' + str(vectorc[1]) + ' ' + str(vectorc[2]) )
fout.write('\n# \n# Lattice vector scale: ' + str(constant))
fout.write('\n# Number of atoms in unit cell: ' + str(no_atoms))
fout.write('\n# Number of fixed atoms: ' + str(no_fixed))
fout.write('\n# Number of free atoms: ' + str(no_free))

fout.write('\n#\n# Position of fixed atoms, if any (lattice coordinates):')
for i in range(0,no_fixed):
  fout.write('\n# ' + str(fixed_atoms[i,0]) + ' ' + str(fixed_atoms[i,1]) + ' ' + str(fixed_atoms[i,2]) )

fout.write('\n#\n# Equilibrium positions of free atoms (lattice coordinates):')
for i in range(0,no_free):
  fout.write('\n# ' + str(free_atoms_equil[i,0]) + ' ' + str(free_atoms_equil[i,1]) + ' ' + str(free_atoms_equil[i,2]) )

fout.write('\n# \n# Generated configurations: \n')
fout.flush()   # clears file output buffer
os.fsync(fout.fileno())  # clears file output buffer

# initialize counters
z           = 0
no_rejected = 0
no_accepted = 0
no_con      = 0

# multiplies vector by "constant" (used for scaling lattice vectors
def multiply(v):
    return [ v[i]*constant for i in range(len(v)) ]    
    
# calculates magnitude of vector
def magnitude(v):
    return math.sqrt(sum(v[i]*v[i] for i in range(len(v))))
    
# normalizes vector
def normalize(v):
    vmag = magnitude(v)
    return [ v[i]/vmag  for i in range(len(v)) ]
   

# distance between two points in oblique coordinate system
def getDistance(p1,p2):
    diffx = p1[0]-p2[0]
    diffy = p1[1]-p2[1]
    diffz = p1[2]-p2[2]
    distance = math.sqrt((diffx*diffx)*(l*l) + (diffy*diffy)*(w*w) + (diffz*diffz)*(h*h) + 2*diffx*diffy*l*w*np.dot(vectora_norm,vectorb_norm) + 2*diffy*diffz*w*h*np.dot(vectorb_norm,vectorc_norm) + 2*diffz*diffx*h*l*np.dot(vectora_norm,vectorc_norm)) 
    #print distance
    return distance
    

# scale unit vectors
vectora = multiply(vectora)
vectorb = multiply(vectorb)
vectorc = multiply(vectorc)

# unit vector magnitudes
l = magnitude(vectora)
w = magnitude(vectorb)
h = magnitude(vectorc)

# normalize unit vectors
vectora_norm = normalize(vectora)
vectorb_norm = normalize(vectorb)
vectorc_norm = normalize(vectorc)



# generate random configs and check distances
while no_accepted < no_configs: 

    print 'Configuration #',no_con+1,':'

    coords   = np.zeros([no_atoms,no_dim])
    compares = np.zeros([no_atoms,no_dim])
    returns  = np.zeros([no_atoms,no_dim])
 
    ## for each fixed atom, set coordinates
    for i in range(0,no_fixed):
        coords[i]   = fixed_atoms[i,:]    
        compares[i] = fixed_atoms[i,:]    
        returns[i]  = fixed_atoms[i,:]    
    
    # for each free atom, generate random coordinates
    for a in range (no_fixed,no_atoms):
        for b in range(0,no_dim): 
            random_num = random.uniform(pert_min,pert_max)
            coords[a,b]   = free_atoms_equil[a-no_fixed,b] + random_num 
            compares[a,b] = free_atoms_equil[a-no_fixed,b] + random_num  
            returns[a,b]  = free_atoms_equil[a-no_fixed,b] + random_num 
    
            
    ## print coordinates of each atom        
    for a in range (0,no_atoms):
            print '     Atom ',a+1,':',coords[a,:]
    
    # calculate distances between all atoms in unit cell and surrounding unit cells
    for a in range(0,no_atoms): #navigate through coord_array
        for b in range(0,no_atoms): #navigate through compare_array
            for c in range(0,no_dim): #change y axis
                
                #y-1 or y+1
                if no_dim > 2:                
                    if c == 1:            
                        compares[b,1] = compares[b,1] - 1.
                    elif c == 2:
                        compares[b,1] = compares[b,1] + 1.
                    
                #at intial position
                if getDistance(coords[a,:],compares[b,:]) != 0:
                    if getDistance(coords[a,:],compares[b,:]) < reject_distance:
                        z = z + 1
                
                if getDistance(coords[a,:],compares[b,:]) == 0:
                    if b != a:
                        z = z + 1
            
                #x-1        
                compares[b,0] = compares[b,0] - 1.
                if getDistance(coords[a,:],compares[b,:]) < reject_distance:
                    z = z + 1
            
                #z+1        
                compares[b,2] = compares[b,2] + 1.
                if getDistance(coords[a,:],compares[b,:]) < reject_distance:
                    z = z + 1
                
                #x+1
                compares[b,0] = compares[b,0] + 1.
                if getDistance(coords[a,:],compares[b,:]) < reject_distance:
                    z = z + 1
                
                #x+1
                compares[b,0] = compares[b,0] + 1.
                if getDistance(coords[a,:],compares[b,:]) < reject_distance:
                    z = z + 1
                
                #z-1
                compares[b,2] = compares[b,2] - 1.
                if getDistance(coords[a,:],compares[b,:]) < reject_distance:
                    z = z + 1
                
                #z-1
                compares[b,2] = compares[b,2] - 1.
                if getDistance(coords[a,:],compares[b,:]) < reject_distance:
                    z = z + 1
                
                #x-1
                compares[b,0] = compares[b,0] - 1.
                if getDistance(coords[a,:],compares[b,:]) < reject_distance:
                    z = z + 1
                
                #x-1
                compares[b,0] = compares[b,0] - 1.
                if getDistance(coords[a,:],compares[b,:]) < reject_distance:
                    z = z + 1
                    
                #z+1        
                compares[b,2] = compares[b,2] + 1.
                if getDistance(coords[a,:],compares[b,:]) < reject_distance:
                    z = z + 1
                
                #back to initial position (x and z coordinates)
                compares[b,0] = compares[b,0] + 1.
                
               
                #back to initial position (y coordinate)            
                if no_dim > 2:                
                    if c == 1:            
                        compares[b,1] = compares[b,1] + 1.
                    elif c == 2:
                        compares[b,1] = compares[b,1] - 1.
                
                for d in range (0,no_dim):
                    compares[b,d] = returns[b,d]
    
    # if any of the atoms were too close,
    if z > 0:
        no_rejected = no_rejected + 1    
        print '     configuration rejected'
    elif z == 0:
        no_accepted = no_accepted + 1
        print '     configuration accepted'
        # write accepted configuration to output file        
        for a in range(0,no_atoms):
            for b in range(0,no_dim):            
                fout.write('{0:.5f}'.format(coords[a,b]))
                fout.write(" ")
            fout.write("      ")
        fout.write('\n')
        fout.flush() # clears file output buffer
        os.fsync(fout.fileno())  # clears file output buffer
        ### print coord_array
    print '     Number of accepted configurations: ',no_accepted
         
    z = 0
    no_con = no_con + 1
        
print ''
print 'Total  number of configurations   :',no_con
print 'Number of configurations accepted :',no_accepted
print 'Number of configurations rejected :',no_rejected

fout.close    
