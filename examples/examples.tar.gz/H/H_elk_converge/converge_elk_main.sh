#!/bin/bash
#
# automates the elk convergence study process. analyze results afterwards since this isn't very robust and some human expertise may be necessary (hints later on)
#
# environment variable ELKROOT must be set to elk installation directory

#--- USER INPUTS --------
# example: 
# elements='Si  O'
elements='H'
#-----------------------

### delete old directories if they exist
rm -rf rmt_check rgkmax*.*



### MAKE LOCAL COPIES OF ELK SPECIES FILES SO THEY CAN BE EDITED IF NECESSARY
for elem in $elements; do
  cp $ELKROOT/species/${elem}.in .
  ln -sf ../${elem}.in murn_template/${elem}.in
done



### REDUCE MUFFIN-TIN RADII (RMT) IF NECESSARY

# make directory
cp -r murn_template rmt_check; cd rmt_check
sed -i 's/{rgkmax}/7.0/g' templatedir/elk.in.template   # set arbitrary rgkmax so elk will run

# run elk at smallest lattice constant that will be tested
echo 'running first point in sweep to determine if muffin-tin radius needs to be adjusted'
./murnaghan_main.py asdasfsdf   # passing in an input tells script to run only first point

# read reduced muffin tin radii if they exist, and edit local species
for elem in $elements; do
  # check if muffin tin radius reduced
  rmt=$(grep 'reduced muf' workdir_s.1/elk.out | grep "(${elem})" | awk '{print $12}')
  
  # if elk had to reduce rmt, edit rmt in local species file
  if [ -n "$rmt" ]; then
    echo "reducing muffin tin radius in local $elem species file to $rmt"
    cp ${elem}.in ${elem}.in.original
    awk -v rmt_awk=$rmt 'NR==5 {$2=rmt_awk}1' ${elem}.in > s_tmp 
    mv s_tmp ${elem}.in
  else
    echo "did not need to reduce muffin-tin radius for element $elem" 
  fi
done

# back to main *_elk_converge_directory
cd ..



### RGKMAX CONVERGENCE
echo -e "\n\n\n\nStarting rgkmax convergence\n"
rgkmax_list='7.0  7.5  8.0  8.5  9.0  9.5  10.0'
for rgkm in $rgkmax_list; do
  echo "--- RGKMAX=$rgkm ---"
  cp -r murn_template rgkmax$rgkm; cd rgkmax$rgkm
  # edit rgmax in templatedir/elk.in
  sed -i "s/{rgkmax}/$rgkm/g" templatedir/elk.in.template
  # run murnaghan script
  ./murnaghan_main.py
  cd ..
done



# check change in bulk modulus (explain why bulk mod and not lattice const)




### SYMLINK CONVERGED SOLUTION
