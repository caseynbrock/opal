#!/usr/bin/env python

import sys
import numpy as np
import matplotlib.pyplot as plt
sys.dont_write_bytecode = True

from eosfit_in import cell_shape  
import murnaghan_main  # for vol_of_s, a_of_s, and murnaghan eqn 

#def Murnaghan(parameters,vol):
#    # given a vector of parameters and volumes, return a vector of energies.
#    #equation From PRB 28,5480 (1983)
#    E0 = parameters[0]
#    B0 = parameters[1]
#    BP = parameters[2]
#    V0 = parameters[3]
#    E = E0 + B0*vol/BP*(((V0/vol)**BP)/(BP-1)+1) - V0*B0/(BP-1.)
#    return E

# read E and v data from file
energy_volume_data = np.loadtxt('energies.dat')
s    = energy_volume_data[:,0]
a    = energy_volume_data[:,1]
vols = energy_volume_data[:,2]
E    = energy_volume_data[:,3]

# read murnaghan equation paramters from file
murnaghan_parameters=[0,0,0,0]
with open('murnaghan_parameters.dat') as printed_results:
    for line in printed_results:
        if 'E_0:' in line:
            murnaghan_parameters[0] = float(line.split()[-1])
        if 'B_0 (bulk modulus):' in line:
            murnaghan_parameters[1] = float(line.split()[-1])
        if 'B_0p:' in line:
            murnaghan_parameters[2] = float(line.split()[-1])
        if 'V_0:' in line:
            murnaghan_parameters[3] = float(line.split()[-1])
    
### PLOTTING ###
# plot calculated E vs. v data
plt.plot(a, E, 'ro', label='calculated energies')
# plot murnaghan fit
sfit = np.linspace(s[0], s[-1], 200)
vfit = murnaghan_main.vol_of_s(sfit, cell_shape)
afit = murnaghan_main.a_of_s(sfit, cell_shape)
plt.plot(afit, murnaghan_main.murnaghan(murnaghan_parameters, vfit), 
         label='Murnaghan EOS fit')
plt.xlabel('a (bohr)')
plt.ylabel('Energy (Ryd)')
plt.legend(loc='best')

#add some text to the figure in figure coordinates
#ax = gca()
#text(0.4,0.5,'Min volume = %1.2f $\AA^3$' % murnpars[3],
#     transform = ax.transAxes)
#text(0.4,0.4,'Bulk modulus = %1.2f eV/$\AA^3$ = %1.2f GPa' % (murnpars[1],
#                                                              murnpars[1]*160.21773)
#     , transform = ax.transAxes)
#savefig('a-eos.png')
plt.show(block=False)
raw_input('Press enter to exit plots...')

