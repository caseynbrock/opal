# input file for murnaghan_main.py
# these scripts vary the lattice paramters of a crystal and fit the resulting energies to the murnaghan equation of state
# the equilibrium lattice constant and bulk modulus are derived from this fit
# results are output to murnaghan_pararmeters.dat
# 
# cell shape options:
# cubic: a=b=c alpha=gamma=beta=90 (used for anything with cubic unit cell)
# fcc: a=b=c alpha=gamma=beta=60? (used as primitive cell for many FCCish structures eg. FCC, diamond cubic, zincblende)
# hex: a=b/=c alpha=beta=90 gamma=120 (standard hexagonal cell)
#
# setting the guess lattice constant is different for hex vs. fcc or cubic 
# for fcc/cubic, s_guess is the guess scale (for fcc shape, conventional lattice constant = 2*scale)
# for hex shape, scale_a is the scale for lattice vectors a and b, while scale_c is the scale for lattice vector c. s_guess multiplies scale_a and scale_c and should initially be set to 1.0, although this may be changed to refine calculation later.

cell_shape = 'cubic'

# initial guess for lattice vector scale
#scale_a = 10. # only used if hex
#scale_c = 10. # only used if hex
s_guess = 3.43

# what code we are using to calculate energy
energy_driver_name = 'elk'

# how much to vary scale
# scale is varied from -s_pert*s_guess to +s_pert*s_guess
s_pert = 0.05

# number of sample points for scale
n_points = 5




