#!/bin/bash
#
# puts convergence data in nice easy to read format

echo "rgkmax, lattice constant (Bohr)"
grep "a_0," rgkmax*/murnaghan_parameters.dat | cut -c7- | tr '/' ' ' | sort -g -k 1 | awk '{print $1 "    " $5}'

echo -e "\nrgkmax, lattice constant (Angstroms)"
grep ang rgkmax*/murnaghan_parameters.dat | cut -c7- | tr '/' ' ' | sort -g -k 1 | awk '{print $1 "    " $4}'

echo -e "\nrgkmax, bulk modulus (GPa)"
grep GPa rgkmax*/murnaghan_parameters.dat | cut -c7- | tr '/' ' ' | sort -g -k 1 | awk '{print $1 "    " $4}'
