"""
Created on Wed Jul 16 13:21:16 2014

@author: Izany
"""
"""
Edited 08/06/14
by Casey Brock

Original is is Izany's files: /home/mdsallmi/python_configurations/lattice_argv_no_plot.py

"""

print "importing libraries"
import math
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt


### USER INPUTS ###############################################################
filename = "configs.dat"  #input file

#scale for lattice vectors
constant = 1. # arbitrary really

#lattice vectors
vectora = [1.,  0.,  0. ]
vectorb = [0.,  1.,  0. ]
vectorc = [0.,  0.,  1. ]

reject = 161.04 #only needs to be specified if plotting large spheres at corners
###############################################################################



print "initializing plot"
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
    


print "defining functions"
def magnitude(v):
    return math.sqrt(sum(v[i]*v[i] for i in range(len(v))))    
def normalize(v):
    vmag = magnitude(v)
    return [ v[i]/vmag  for i in range(len(v)) ]
def multiply(v):
    return [ v[i]*constant for i in range(len(v)) ]    

print "scaling unit vectors"
# scale unit vectors
vectora = multiply(vectora)
vectorb = multiply(vectorb)
vectorc = multiply(vectorc)

print "normalizing unit vectors"
# normalize unit vectors
vectora_norm = normalize(vectora)
vectorb_norm = normalize(vectorb)
vectorc_norm = normalize(vectorc)


print "reading file"
coords = np.loadtxt(filename)
no_atoms = coords.shape[1]/3
no_configs = coords.shape[0]

print "creating scatter points"
#to create scatter points
for i in range (0,no_configs):        
    for j in range (0,no_atoms):        
        xs = coords[i,0+3*j]*vectora[0] + coords[i,1+3*j]*vectorb[0] + coords[i,2+3*j]*vectorc[0]  
        ys = coords[i,0+3*j]*vectora[1] + coords[i,1+3*j]*vectorb[1] + coords[i,2+3*j]*vectorc[1] 
        zs = coords[i,0+3*j]*vectora[2] + coords[i,1+3*j]*vectorb[2] + coords[i,2+3*j]*vectorc[2]
        # different colors for different atom types
        if j<2:
            ax.scatter(xs, ys, zs, color='r')
        else:
            ax.scatter(xs, ys, zs, 'b')
        

print "creating unit cell"
#to create lattice cube
ax.plot([0,vectora[0]],[0,vectora[1]],[0,vectora[2]])
ax.plot([0,vectorb[0]],[0,vectorb[1]],[0,vectorb[2]])
ax.plot([0,vectorc[0]],[0,vectorc[1]],[0,vectorc[2]])

ax.plot([vectora[0],vectora[0]+vectorc[0]],[vectora[1],vectora[1]+vectorc[1]],[vectora[2],vectora[2]+vectorc[2]])
ax.plot([vectora[0],vectora[0]+vectorb[0]],[vectora[1],vectora[1]+vectorb[1]],[vectora[2],vectora[2]+vectorb[2]])

ax.plot([vectorb[0],vectorb[0]+vectorc[0]],[vectorb[1],vectorb[1]+vectorc[1]],[vectorb[2],vectorb[2]+vectorc[2]])
ax.plot([vectorb[0],vectorb[0]+vectora[0]],[vectorb[1],vectorb[1]+vectora[1]],[vectorb[2],vectorb[2]+vectora[2]])

ax.plot([vectorc[0],vectorc[0]+vectora[0]],[vectorc[1],vectorc[1]+vectora[1]],[vectorc[2],vectorc[2]+vectora[2]])
ax.plot([vectorc[0],vectorc[0]+vectorb[0]],[vectorc[1],vectorc[1]+vectorb[1]],[vectorc[2],vectorc[2]+vectorb[2]])

ax.plot([vectora[0]+vectorb[0],vectora[0]+vectorb[0]+vectorc[0]],[vectora[1]+vectorb[1],vectora[1]+vectorb[1]+vectorc[1]],[vectora[2]+vectorb[2],vectora[2]+vectorb[2]+vectorc[2]])
ax.plot([vectora[0]+vectorc[0],vectora[0]+vectorb[0]+vectorc[0]],[vectora[1]+vectorc[1],vectora[1]+vectorb[1]+vectorc[1]],[vectora[2]+vectorc[2],vectora[2]+vectorb[2]+vectorc[2]])
ax.plot([vectorb[0]+vectorc[0],vectora[0]+vectorb[0]+vectorc[0]],[vectorb[1]+vectorc[1],vectora[1]+vectorb[1]+vectorc[1]],[vectorb[2]+vectorc[2],vectora[2]+vectorb[2]+vectorc[2]])

#draw sphere
u, v = np.mgrid[0:2*np.pi:20j, 0:np.pi:10j]
x=np.cos(u)*np.sin(v)
y=np.sin(u)*np.sin(v)
z=np.cos(v)
#ax.plot_wireframe(np.multiply(x,0.5*reject), np.multiply(y,0.5*reject), np.multiply(z,0.5*reject), color="r")
#ax.plot_wireframe(np.multiply(x,0.5*reject)+constant, np.multiply(y,0.5*reject)+constant, np.multiply(z,0.5*reject), color="r")

print "showing plot"
plt.show(block=False)
raw_input('Press enter to exit plots...') 
